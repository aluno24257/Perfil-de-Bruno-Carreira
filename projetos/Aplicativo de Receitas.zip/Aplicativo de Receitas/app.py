import sys
import ctypes

from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QLabel, QLineEdit, QTextEdit, QPushButton, QVBoxLayout, QHBoxLayout, QListWidget, QMessageBox


class AppReceitas(QMainWindow):
    def __init__(self):
        super().__init__()
        self.receitas = []

        self.setWindowTitle("Aplicativo de Receitas")
        self.setGeometry(300, 300, 600, 400)

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        self.setWindowIcon(QIcon("icone.png"))
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Aplicativo de Receitas")

        self.label_nome = QLabel("Nome da Receita:")
        self.entrada_nome = QLineEdit()

        self.label_ingredientes = QLabel("Ingredientes:")
        self.entrada_ingredientes = QLineEdit()

        self.label_passos = QLabel("Passos:")
        self.entrada_passos = QTextEdit()

        self.botao_salvar = QPushButton("Salvar")
        self.botao_salvar.clicked.connect(self.salvar_receita)

        self.lista_receitas = QListWidget()
        self.lista_receitas.itemClicked.connect(self.exibir_receita_selecionada)

        self.botao_excluir = QPushButton("Excluir Receita")
        self.botao_excluir.clicked.connect(self.excluir_receita)

        self.botao_limpar = QPushButton("Limpar Campos")
        self.botao_limpar.clicked.connect(self.limpar_campos)

        layout_direita = QVBoxLayout()
        layout_direita.addWidget(self.label_nome)
        layout_direita.addWidget(self.entrada_nome)
        layout_direita.addWidget(self.label_ingredientes)
        layout_direita.addWidget(self.entrada_ingredientes)
        layout_direita.addWidget(self.label_passos)
        layout_direita.addWidget(self.entrada_passos)
        layout_direita.addWidget(self.botao_salvar)
        layout_direita.addWidget(self.botao_excluir)
        layout_direita.addWidget(self.botao_limpar)

        layout_esquerda = QVBoxLayout()
        layout_esquerda.addWidget(QLabel("Receitas Adicionadas:"))
        layout_esquerda.addWidget(self.lista_receitas)

        layout_principal = QHBoxLayout()
        layout_principal.addLayout(layout_esquerda)
        layout_principal.addLayout(layout_direita)

        self.central_widget.setLayout(layout_principal)

    def salvar_receita(self):
        nome = self.entrada_nome.text()
        ingredientes = self.entrada_ingredientes.text().split(", ")
        passos = self.entrada_passos.toPlainText().split("\n")

        if nome and ingredientes and passos:
            nova_receita = Receita(nome, ingredientes, passos)
            self.receitas.append(nova_receita)
            self.lista_receitas.addItem(nome)
            self.limpar_campos()
        else:
            QMessageBox.warning(self, "Erro", "Por favor, preencha todos os campos antes de salvar.")

    def exibir_receita_selecionada(self, item):
        nome_receita = item.text()
        for receita in self.receitas:
            if receita.nome == nome_receita:
                self.entrada_nome.setText(receita.nome)
                self.entrada_ingredientes.setText(", ".join(receita.ingredientes))
                self.entrada_passos.setText("\n".join(receita.passos))
                break

    def excluir_receita(self):
        nome_receita = self.entrada_nome.text()
        for receita in self.receitas:
            if receita.nome == nome_receita:
                self.receitas.remove(receita)
                self.lista_receitas.takeItem(self.lista_receitas.currentRow())
                self.limpar_campos()
                break

    def limpar_campos(self):
        self.entrada_nome.clear()
        self.entrada_ingredientes.clear()
        self.entrada_passos.clear()


class Receita:
    def __init__(self, nome, ingredientes, passos):
        self.nome = nome
        self.ingredientes = ingredientes
        self.passos = passos


if __name__ == "__main__":
    app = QApplication(sys.argv)
    janela = AppReceitas()
    janela.show()
    sys.exit(app.exec_())
